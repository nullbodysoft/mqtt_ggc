import serial
import time

ser = serial.Serial("/dev/ttyACM0",baudrate=9600, timeout=40, writeTimeout=10)
ser.open

while 1:
	while ser.inWaiting() == 0:
		time.sleep(0.1)
	buff = ser.readline().strip('\n\r')
	print buff
	ser.write("\n")
