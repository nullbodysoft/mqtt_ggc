#!/bin/sh
sync
curl -u root:doghunter http://127.0.0.1/data/put/reset/1
