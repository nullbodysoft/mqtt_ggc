/cygdrive/d/php/php.exe -q check_air_test5.php
