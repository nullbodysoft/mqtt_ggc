<?php
include_once('check_air_def.php');

function get_sm_table(){
	$SM=array();
	$SM[AIR_ON]=array();
	$SM[AIR_ON][AIR_OFF]		= array('min_count' => 0 , 'next' => AIR_OFF,      'chk_dom' => 0, 'chk_dob' => 1);
	$SM[AIR_ON][AIR_FAN_ONLY]	= array('min_count' => 0 , 'next' => AIR_FAN_ONLY, 'chk_dom' => 0, 'chk_dob' => 1);
	$SM[AIR_ON][AIR_BYPASS]		= array('min_count' => 0 , 'next' => AIR_FAN_ONLY, 'chk_dom' => 0, 'chk_dob' => 1);
	$SM[AIR_OFF]=array();
	$SM[AIR_OFF][AIR_ON]		= array('min_count' => 0 , 'next' => AIR_FAN_ONLY, 'chk_dom' => 0, 'chk_dob' => 0);
	$SM[AIR_OFF][AIR_FAN_ONLY]	= array('min_count' => 0 , 'next' => AIR_FAN_ONLY, 'chk_dom' => 0, 'chk_dob' => 0);
	$SM[AIR_OFF][AIR_BYPASS]	= array('min_count' => 0 , 'next' => AIR_FAN_ONLY, 'chk_dom' => 0, 'chk_dob' => 0);
	$SM[AIR_FAN_ONLY]=array();
	$SM[AIR_FAN_ONLY][AIR_ON]	= array('min_count' => 0 , 'next' => AIR_ON,       'chk_dom' => 1, 'chk_dob' => 0);
	$SM[AIR_FAN_ONLY][AIR_OFF]	= array('min_count' => 0 , 'next' => AIR_OFF,      'chk_dom' => 0, 'chk_dob' => 0);
	$SM[AIR_FAN_ONLY][AIR_BYPASS]	= array('min_count' => 0 , 'next' => AIR_BYPASS,   'chk_dom' => 1, 'chk_dob' => 0);
	$SM[AIR_BYPASS]=array();
	$SM[AIR_BYPASS][AIR_ON]		= array('min_count' => 0 , 'next' => AIR_FAN_ONLY, 'chk_dom' => 0, 'chk_dob' => 1);
	$SM[AIR_BYPASS][AIR_OFF]	= array('min_count' => 0 , 'next' => AIR_FAN_ONLY, 'chk_dom' => 0, 'chk_dob' => 0);
	$SM[AIR_BYPASS][AIR_FAN_ONLY]	= array('min_count' => 0 , 'next' => AIR_FAN_ONLY, 'chk_dom' => 0, 'chk_dob' => 1);
	return $SM;
}

function state_exec_all(&$AIR,$last_id=MAX_AIR){
	$air_list=array_keys($AIR);
	foreach($air_list as $id){
		if($id>MAX_AIR) continue;
		if($id>$last_id) continue;
		if(!is_numeric($id) || $id<1 || $id>MAX_AIR){
			air_log(__FUNCTION__,"Error unknown air id: '$id'");
			unset($AIR[$id]);
			continue;
		}
		state_exec($AIR,$id);
	}
}

function state_exec(&$AIR,$id){
	$SM=get_sm_table();

	$CS=$AIR[$id]['state'];
	$TS=$AIR[$id]['target_state'];
	$C=$AIR[$id]['count'];

	if($AIR[$id]['state']==$AIR[$id]['target_state'] || $AIR[$id]['target_state']==AIR_NOT_CHANGE){
		$AIR[$id]['target_state']=AIR_NOT_CHANGE;
		$AIR[$id]['count']++;
		air_log('  '.__FUNCTION__,"air $id: No state change. state: ".air_state_txt($CS));
		return AIR_NOT_CHANGE;
	}

	if(isset($SM[$CS])){
		if(isset($SM[$CS][$TS])){
			$smmap=$SM[$CS][$TS];
			$min_count=$smmap['min_count'];
			$next=$smmap['next'];
			$chk_dom=$smmap['chk_dom'];
			$chk_dob=$smmap['chk_dob'];
			if($C>=$min_count){
				if($chk_dom && $AIR[$id]['dom']>0){
					$AIR[$id]['count']++;
					air_log('  '.__FUNCTION__,"air $id: delay_on: ".(AIR_DoM-$AIR[$id]['dom'])."/".AIR_DoM.". state: ".air_state_txt($CS));
				}elseif($chk_dob && $AIR[$id]['dob']>0){
					$AIR[$id]['count']++;
					air_log('  '.__FUNCTION__,"air $id: delay_off: ".(AIR_DoB-$AIR[$id]['dob'])."/".AIR_DoB.". state: ".air_state_txt($CS));
				}else{
					if($TS==$next){
						$AIR[$id]['state']=$TS;
						$AIR[$id]['target_state']=AIR_NOT_CHANGE;
						$AIR[$id]['count']=0;
						air_log('  '.__FUNCTION__,"air $id: Change from ".air_state_txt($CS)."(".(($C+1)*LOOP_TIME)." min) to ".air_state_txt($TS).". state: ".air_state_txt($TS));
						return AIR_NOT_CHANGE;
					}else{
						$AIR[$id]['state']=$next;
						$AIR[$id]['count']=0;
						air_log('  '.__FUNCTION__,"air $id: Change from ".air_state_txt($CS)."(".(($C+1)*LOOP_TIME)." min) to ".air_state_txt($next).". state: ".air_state_txt($next));
						return $next;
					}
				}
			}else{
				$AIR[$id]['count']++;
				air_log('  '.__FUNCTION__,"air $id: loop: ".$AIR[$id]['count']."/".$min_count.". state: ".air_state_txt($CS));
				return $CS;
			}
		}else{
			air_log('  '.__FUNCTION__,"air $id: Error target state not found: $TS. state: ".air_state_txt($CS));
			return AIR_NOT_CHANGE;
		}
	}else{
		air_log('  '.__FUNCTION__,"air $id: Error current state not found: $CS. state: ".air_state_txt($CS));
		return AIR_NOT_CHANGE;
	}
	return -1;
}
?>
