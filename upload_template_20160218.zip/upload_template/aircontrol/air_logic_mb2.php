<?php
# VERSION 20151223
# main: n
# backup: b
# switch every 24H
# +25c => turn on backup
# +28c => trun on another backup

# air_type: main, backup, idle

include_once('check_air_def.php');
include_once('check_air_function2.php');


function calc_air_mb(&$AIR,$AIR_DATA,$air_list,$num_main,$max_on_minute,$a_temp,$c_temp,$c_temp2,$backup_min,$switch_h=-1,$switch_m=-1, $wait_all_main_on_state=AIR_ON){
	$AIR_WEIGHT=$GLOBALS['AIR_WEIGHT'];
	$old_air_info=array();
	$main_list=array();
	# get all main
	$main_list=get_all_main($AIR,$air_list);
	# get all backup
	$backup_list=get_all_backup($AIR,$air_list);
	air_log(__FUNCTION__,"temp: $a_temp/$c_temp/$c_temp2 main: ".get_air_list_weight($main_list)."/$num_main ".join($main_list,',').' backup: '.count($backup_list).' '.join($backup_list,','),LOG_INFO);

	# if too many main, remove it
/*	if(count($main_list)>$num_main){
		air_log(__FUNCTION__,'Too many main',LOG_DEBUG);
		$old_main=remove_1main($AIR,$main_list);
		if($old_main>0) $main_list=get_all_main($AIR,$air_list);
	}
*/
	$w=get_air_list_weight($main_list);
	if($w>$num_main){
		$id=remove_1main_test($AIR,$main_list);
		if($id>0){
			if(($w-get_air_weight($id))>=$num_main){
				air_log(__FUNCTION__,'Too many main',LOG_DEBUG);
				$old_main=remove_1main($AIR,$main_list);
				if($old_main>0) $main_list=get_all_main($AIR,$air_list);
			}
		}
	}

	# set main counter if not set
	foreach($main_list as $id){
		if(!isset($AIR[$id]['count_m'])) set_air_count_m($AIR,$id,1);
	}

	# if not enough main, get more
	for($i=0; $i<2; $i++){
		$w=get_air_list_weight($main_list);
		if($w>=$num_main) break;
		$new_main=set_new_main($AIR,$air_list,$old_air_info);
		if($new_main>0) $main_list=get_all_main($AIR,$air_list);
	}

	# switch air
	$h=date("H"); $m=date("i"); # switch time
	$min_main_on_minute=0;
	foreach($main_list as $id){
		$cur_main_on_minute=(get_air_counter($AIR,$id)+1)*LOOP_TIME;
		if($min_main_on_minute == 0) $min_main_on_minute=$cur_main_on_minute;
		if($cur_main_on_minute < $min_main_on_minute) $min_main_on_minute=$cur_main_on_minute;
	}
	if($min_main_on_minute > $max_on_minute)
		air_log(__FUNCTION__,"main is on at least $min_main_on_minute minute",LOG_INFO);
	if($num_main>0 && (($h == $switch_h && $m == $switch_m) || ($min_main_on_minute > $max_on_minute))){
		air_log(__FUNCTION__,"rotate main at $h:$m",LOG_INFO);
		# set_new_main, if new main was backup  => copy backup info to old main
		$new_main=set_new_main($AIR,$air_list,$old_air_info);
		if($new_main>0){
			$old_main=remove_1main($AIR,$main_list);
			if($old_main>0 && $old_air_info['type']=='backup'){
				air_log(__FUNCTION__,"set air $old_main as backup",LOG_INFO);
				$AIR[$old_main]=$old_air_info;
			}
		}
	}

	# check temp, trun on if too hot
	$backup_list=get_all_backup($AIR,$air_list);
	if($a_temp > $c_temp2){
		if(count($backup_list)<2) {
			$new_backup=set_new_backup($AIR,$air_list);
			$backup_list=get_all_backup($AIR,$air_list);
		}
	}elseif($a_temp > $c_temp){
		if(count($backup_list)<1) {
			$new_backup=set_new_backup($AIR,$air_list);
			$backup_list=get_all_backup($AIR,$air_list);
		}
	}
	# turn off if too many backup
	$backup_list=get_all_backup($AIR,$air_list);
	$max_backup=count($backup_list);
	if($a_temp < $c_temp){
		$max_backup=0;
	}elseif($a_temp < $c_temp2){
		$max_backup=1;
	}
	if(count($backup_list) > $max_backup){
		remove_1backup($AIR,$backup_list,$backup_min);
	}

	# all main on? => turn on
	$main_list=get_all_main($AIR,$air_list);
	$all_main_on=1;
	foreach($main_list as $id){
		$airstate=air_state($AIR,$id);
		if($airstate!=AIR_ON) {
			$all_main_on=0;
			if($AIR[$id]['target_state']!=AIR_ON) set_air($AIR,$id,AIR_ON);
		}else{
			if((get_air_counter($AIR,$id)+1)*LOOP_TIME<4) $all_main_on=0;
		}
	}
	# turn off idle if all main on
	foreach($air_list as $id){
		if(trim(get_air_type($AIR,$id))=='') set_air_type($AIR,$id,'idle');
		if(get_air_type($AIR,$id)=='idle' && (is_air_on($AIR,$id) || is_air_bypass($AIR,$id) || air_state($AIR,$id)==AIR_FAN_ONLY) ){
			if($all_main_on){
				set_air($AIR,$id,AIR_OFF);
				air_log(__FUNCTION__,"turn off $id",LOG_INFO);
			}else{
				if($wait_all_main_on_state==AIR_FAN_ONLY && air_state($AIR,$id)!=AIR_FAN_ONLY){
					set_air($AIR,$id,AIR_FAN_ONLY);
				}
				air_log(__FUNCTION__,"wait for all main on, postpone turning off air $id",LOG_DEBUG);
				break;
			}
		}
	}
	return;
}

function get_all_main(&$AIR,$air_list){
	$main_list=array();
	foreach($air_list as $id){
		if(isset($AIR[$id]['type'])){
			if($AIR[$id]['type']=='slave') set_air_type($AIR,$id,'main'); // migrate from version 3
			if(get_air_type($AIR,$id)=='main') $main_list[]=$id;
		}
	}
	return $main_list;
}
function get_all_backup($AIR,$air_list){
	$backup_list=array();
	foreach($air_list as $id){
		if(isset($AIR[$id]['type'])){
			if(get_air_type($AIR,$id)=='backup') $backup_list[]=$id;
		}
	}
	return $backup_list;
}
function set_new_main(&$AIR,$air_list,&$old_air_info){
	$ret=0;
	$new_main_c=array();
	foreach($air_list as $id){
		$t='idle'; $count_m=0;
		if(isset($AIR[$id]['type'])) $t=get_air_type($AIR,$id);
		if($t=='main') continue;
		if(isset($AIR[$id]['count_m'])) $count_m=intval($AIR[$id]['count_m']);
		$new_main_c[$id]=$count_m;
		if(is_air_on($AIR,$id)) $new_main_c[$id]++;
	}
	if(count($new_main_c)>0){
		#air_log(__FUNCTION__,'main candidate: '.join(array_keys($new_main_c),',').'/'.join($new_main_c,','),LOG_DEBUG);
		#asort($new_main_c);
		#$id=key($new_main_c);
		$id=get_min_rand($new_main_c);
		if($id>0){
			$old_air_info=$AIR[$id];
			set_air_type($AIR,$id,'main');
			if(is_air_on($AIR,$id)) set_air_counter($AIR,$id,0);
			set_air($AIR,$id,AIR_ON);
			set_air_count_m($AIR,$id,$new_main_c[$id]+1);
			$ret=$id;
			air_log(__FUNCTION__,'main candidate: '.join(array_keys($new_main_c),',').'/'.join($new_main_c,',')." select: $id",LOG_INFO);
		}
	}else{
		air_log(__FUNCTION__,'cannot get new main',LOG_DEBUG);
	}
	return $ret;
}
function set_new_backup(&$AIR,$air_list){
	$ret=0;
	$new_backup_c=array();
	foreach($air_list as $id){
		$t='idle'; $count_b=0;
		if(isset($AIR[$id]['type'])) $t=get_air_type($AIR,$id);
		if($t!='idle') continue;
		if(isset($AIR[$id]['count_b'])) $count_b=intval($AIR[$id]['count_b']);
		$new_backup_c[$id]=$count_b;
	}
	if(count($new_backup_c)>0){
		#air_log(__FUNCTION__,'backup candidate: '.join(array_keys($new_backup_c),',').'/'.join($new_backup_c,','),LOG_DEBUG);
		#asort($new_backup_c); reset($new_backup_c);
		#$id=key($new_backup_c);
		$id=get_min_rand($new_backup_c);
		if($id>0){
			set_air_type($AIR,$id,'backup');
			if(is_air_on($AIR,$id)) set_air_counter($AIR,$id,0);
			set_air($AIR,$id,AIR_ON);
			set_air_count_b($AIR,$id,$new_backup_c[$id]+1);
			$ret=$id;
			air_log(__FUNCTION__,'backup candidate: '.join(array_keys($new_backup_c),',').'/'.join($new_backup_c,',')." select: $id",LOG_INFO);
		}
	}else{
		air_log(__FUNCTION__,'cannot get new backup',LOG_DEBUG);
	}
	return $ret;
}

function remove_1backup(&$AIR,$backup_list,$min_on){
	$ret=0;
	$backup_ontime=array();
	foreach($backup_list as $id){
		$t=get_air_type($AIR,$id);
		if($t!='backup') continue;
		$backup_ontime[$id]=(get_air_counter($AIR,$id)+1)*LOOP_TIME;
	}
	if(count($backup_ontime)>0){
		arsort($backup_ontime);
		$id=key($backup_ontime);
		$time=$backup_ontime[$id];
		if($time>$min_on){
			set_air_type($AIR,$id,'idle');
			set_air($AIR,$id,AIR_OFF);
			$ret=$id;
			air_log(__FUNCTION__,"remove backup: $id",LOG_INFO);
		}else{
			air_log(__FUNCTION__,"wait for air $id on > ".$min_on."min",LOG_INFO);
		}
	}else{
		air_log(__FUNCTION__,"no backup to remove",LOG_DEBUG);
	}
	return $ret;
}
function remove_1main(&$AIR,$main_list,$test=0){
	$ret=0;
	$main_ontime=array();
	foreach($main_list as $id){
		$main_ontime[$id]=(get_air_counter($AIR,$id)+1)*LOOP_TIME;
	}
	if(count($main_ontime)>0){
		arsort($main_ontime);
		$id = key($main_ontime);
		if($test==0) set_air_type($AIR,$id,'idle');
		$ret=$id;
		if($test==0) air_log(__FUNCTION__,"remove $id from main list",LOG_INFO);
	}else{
		if($test==0) air_log(__FUNCTION__,"no main to remove",LOG_DEBUG);
	}
	return $ret;
}
function remove_1main_test($AIR,$main_list){
	return remove_1main($AIR,$main_list,1);
}
function set_air_count_m(&$AIR,$id,$count){
	if(!is_numeric($id)) return;
	$AIR[$id]['count_m']=intval($count);
}
function set_air_count_b(&$AIR,$id,$count){
	if(!is_numeric($id)) return;
	$AIR[$id]['count_b']=intval($count);
}
function exec_air_schedule(&$AIR,$sch){
	$h=date('H');	// hour
	$id=1; $last_id=1;
	foreach(explode("\n",$sch) as $s){
		$s=trim($s);
		if(strlen($s)!=24) {
			air_log(__FUNCTION__,"Error: invalid schedule data $s",LOG_DEBUG);
			break;
		}
		$air_cmd=substr($s,$h,1);
		//echo("$id: $s $air_cmd\n");
		switch($air_cmd){
			case 0: set_air_type($AIR,$id,'idle'); 
				break;
			case 1: set_air($AIR,$id,AIR_ON); 
				set_air_type($AIR,$id,'main'); 
				break;
			case 2: set_air($AIR,$id,AIR_BYPASS); 
				set_air_type($AIR,$id,''); 
				break;
		}
		$last_id=$id;
		$id++;
	}
	# check if all main on
	$all_main_on=1;
	for($id=1;$id<=$last_id;$id++){
		if(get_air_type($AIR,$id)!='main') continue;
		if(air_state($AIR,$id)!=AIR_ON) $all_main_on=0;
		if((get_air_counter($AIR,$id)+1)*LOOP_TIME<4) $all_main_on=0;
	}
	# turn off idle if all main on for 4 min
	for($id=1;$id<=$last_id;$id++){
		if(get_air_type($AIR,$id)!='idle') continue;
		if(is_air_off($AIR,$id)) continue;
		if($all_main_on){
			set_air($AIR,$id,AIR_OFF);
			air_log(__FUNCTION__,"turn off $id",LOG_INFO);
		}else{
			air_log(__FUNCTION__,"wait for all main on, postpone turning off air $id",LOG_DEBUG);
		}
	}
}
function get_min_rand($list){
        asort($list);
        $c_list=array();
        $last_count=0;
        foreach($list as $id => $count){
        	air_log(__FUNCTION__,"list: $id:$count",LOG_DEBUG);
                if(count($c_list)>0 && $last_count != $count) break;
                $c_list[]=$id;
                $last_count=$count;
        }
        if(count($c_list)>1){
                $c=count($c_list);
                $r=rand(0,$c-1);
                $id=$c_list[$r];
        	air_log(__FUNCTION__,"have $c, select $r, id: $id",LOG_DEBUG);
        }else{
                $id=current($c_list);
        	air_log(__FUNCTION__,"have only one, id: $id",LOG_DEBUG);
        }
        return $id;
}
function get_air_list_weight($list){
	$AIR_WEIGHT=$GLOBALS['AIR_WEIGHT'];
	$w=0;
	foreach($list as $id){
		if(isset($AIR_WEIGHT[$id])){
			$w=$w+$AIR_WEIGHT[$id];
		}else{
			$w=$w+1; // default weight=1
		}
	}
	return $w;
}
function get_air_weight($id){
	$AIR_WEIGHT=$GLOBALS['AIR_WEIGHT'];
	$w=1;
	if(isset($AIR_WEIGHT[$id])) $w=$AIR_WEIGHT[$id];
	return $w;
}
?>
