<?php
// VERSION: 20160203
//date_default_timezone_set('Asia/Bangkok');
include_once('check_air_def.php');
include_once('check_air_function2.php');
include_once('statemachine.php');
include_once('air_logic_mb2.php');
include_once('site_config.php'); # NUM_AIR, AIR_WEIGHT, default_a_temp, MIN_BACKUP_ON_TIME

$AIR_GROUP=array();

/*
2016-02-03: allow air_group switch_main_h less than 1 for switch main less than 1 hours
*/
#TODO: read from file
/*
 * $NUM_AIRGROUP=1;
$AIR_GROUP[1]=array(
	'air_list'=>array(1,2,3),
	'num_main'=>2,
	'switch_main_h'=>24,
	//'switch_main_h'=>1,
	'temp_sensors'=>'2810FE5606000041,280CEC5606000098,288A695506000051',
	'temp_cond1'=>27,
	'temp_cond2'=>30,
);
 */

	#$log_prio=LOG_INFO;
	$log_prio=LOG_DEBUG;
	if($OS!='WIN'){
		openlog(basename(__FILE__), LOG_PID | LOG_PERROR, LOG_LOCAL1);
	}else{
		openlog(basename(__FILE__), LOG_PID | LOG_PERROR, LOG_USER);
	}

	# check already run
	$run_file="$TMPDIR/_air_run";
	$now=date('H:i');
	$last_run=@file_get_contents($run_file);
	if($now==$last_run) {
		air_log(basename(__FILE__),'Error: already run, exit.',LOG_ERR);
		exit;
	}
	file_put_contents($run_file,$now);

	# default to auto mode;
	$is_auto=1;

	# not run if uptime < 3 min
	if($OS!='WIN'){
		$ut=file_get_contents('/proc/uptime');
		$utA=explode(' ',$ut);
		if($utA[0]<180) exit;
	}

	#air_log('START',"#### ".date('c')." ####"); # php5
	$tz=date("O");
	air_log('START',"#### ".date("Y-m-d\TH:i:s").substr($tz,0,3).":".substr($tz,-2)." ####");
	# Copy init datafile from backup to /tmp
	if(!restore_from_flash_to_tmp(array($AIR_AUTO_FILE,$DATA_AIR_FILE2,$AIR_SCH_0,$AIR_SCH_1,$AIR_SCH_2,$AIR_SCH_3,$AIR_SCH_4,$AIR_SCH_5,$AIR_SCH_6,$AIR_GROUP_FILE))){
		air_log(basename(__FILE__),'Error: Cannot restore file from flash',LOG_ERR);
		exit;
	}

	# get air group from file
	$AIR_GROUP=get_air_group($AIR_GROUP_FILE);
	$NUM_AIRGROUP=count($AIR_GROUP);

	# get air mode
	$tmp=get_air_auto($AIR_AUTO_FILE);
	if($tmp!==false && $tmp>=0 && $tmp<=2){ # TODO: 0=manual, 1=group+temp, 2=schedule
		$is_auto=$tmp;
		air_log(__FILE__,"air_mode: $is_auto");
	}
	
	if(!is_file($INIT_FILE)) {
		air_log(basename(__FILE__),'Error: Data not initialize',LOG_WARNING);
		exit;
	}

	# load air state
	$AIR=load_air_state();	# 1: from air.save
	if($AIR===false) {	# 2: from mcu output file ($AIR_BIT_FILE)
		$AIR=get_air_state_from_board($AIR_BIT_FILE);
		air_log(basename(__FILE__),'Warning: Rebuild Air state from tmp.txt',LOG_WARNING);
	}
	if($AIR===false) {	# 3: from cmd file to mcu (data_air_to_board.txt). initialize to AIR_BYPASS if no data found
		$AIR=air_init();
		air_log(basename(__FILE__),'Warning: Initialize air data',LOG_WARNING);
	}

	$AIR_DATA=load_air_data2($DATA_AIR_FILE2);	# load air data (web cmd)

	if($is_auto==1){
		for($g_id=1;$g_id<=$NUM_AIRGROUP;$g_id++){
			# get data from group
			$temp_sensors = $AIR_GROUP[$g_id]['temp_sensors'];
			$switch_main_h = $AIR_GROUP[$g_id]['switch_main_h'];
			$num_main = $AIR_GROUP[$g_id]['num_main'];
			$air_list = $AIR_GROUP[$g_id]['air_list'];
			$temp_cond1 = $AIR_GROUP[$g_id]['temp_cond1'];
			$temp_cond2 = $AIR_GROUP[$g_id]['temp_cond2'];
			if(isset($AIR_GROUP[$g_id]['min_backup_time_m'])) 
				$MIN_BACKUP_ON_TIME = $AIR_GROUP[$g_id]['min_backup_time_m'];
			$wait_all_main_on_state=AIR_ON;
			if(isset($AIR_GROUP[$g_id]['wait_all_main_on_state']))
				$wait_all_main_on_state=$AIR_GROUP[$g_id]['wait_all_main_on_state'];
			if($NUM_AIRGROUP>1)
				air_log("####","air group $g_id: ".implode(',',$air_list)." ####");

			# load temperature data and average
			$a_temp       = get_average_temp($temp_sensors);
			if(!is_numeric($a_temp)){
				$a_temp = $default_a_temp;
		        	air_log(__FILE__,"# Error: get_average_temp(): invalid temp data, use default: $default_a_temp",LOG_WARNING);
			}
			$a_temp_lpf=lpf($a_temp,'temp_g'.$g_id,0.2);
		       	air_log(__FILE__,"#Average temperature: $a_temp, LPF: $a_temp_lpf");

			# set switch main time
			$sw_h=0; $sw_m=0; // default at 00:00
			$h=date('G');
			if($h % $switch_main_h === 0) $sw_h=$h;
			if($switch_main_h >=1){
			  $switch_main_minute=$switch_main_h*60+10;
			}else{
			  $switch_main_minute=$switch_main_h*60-1;
			  if($switch_main_minute<11) $switch_main_minute=11;
			}      
			calc_air_mb($AIR,$AIR_DATA,$air_list,$num_main,$switch_main_minute,$a_temp_lpf,$temp_cond1,$temp_cond2,$MIN_BACKUP_ON_TIME,$sw_h,$sw_m,$wait_all_main_on_state);
			#calc_air_mb($AIR,$AIR_DATA,$air_list,$num_main,15,$a_temp,$temp_cond1,$temp_cond2,$MIN_BACKUP_ON_TIME,$sw_h,$sw_m);
		}
	}elseif($is_auto==2){
		# weekly schedule
		$dof=date('w'); // day
		$sch_file='';
		switch($dof){
			case 0: $sch_file=$AIR_SCH_0; break;
			case 1: $sch_file=$AIR_SCH_1; break;
			case 2: $sch_file=$AIR_SCH_2; break;
			case 3: $sch_file=$AIR_SCH_3; break;
			case 4: $sch_file=$AIR_SCH_4; break;
			case 5: $sch_file=$AIR_SCH_5; break;
			case 6: $sch_file=$AIR_SCH_6; break;
		}
		if($sch_file==''){
			air_log(__FILE__,"# Error: air schedule file not found $sch_file",LOG_ERR);
			exit;
		}
		air_log(__FILE__," Schedule file: $sch_file",LOG_DEBUG);
		$sch=file_get_contents($sch_file);
		if($sch===false){
			air_log(__FILE__,"# Error: cannot read schedule file $sch_file",LOG_ERR);
			exit;
		}
		$sch=trim($sch);
		exec_air_schedule($AIR,$sch);
	}elseif($is_auto==0){
		# manual
		for($id=1;$id<=$NUM_AIR;$id++){
			if(air_state($AIR,$id)!=$AIR_DATA[$id]){
				set_air($AIR,$id,$AIR_DATA[$id]);
				air_log(__FILE__,"#air$id change state to ".$AIR_DATA[$id]." ".air_state_txt($AIR_DATA[$id]));
			}
		}
	}
	
	# state machine
	state_exec_all($AIR,$NUM_AIR);
	#print_air($AIR,2);
	write_cmd_file($AIR,$AIR_CMD_MAP); # write data_air_to_board
	save_air_state($AIR); # save air state for next round

	# report air status status
	for($id=1;$id<=$NUM_AIR;$id++){
		air_log(__FILE__, "# air $id is ".air_state_txt(air_state($AIR,$id))." for ".($AIR[$id]['count']*LOOP_TIME)." min".' ('.get_air_type($AIR,$id).')');
	}
	
	# copy air_data to backup
	if(!backup_from_tmp_to_flash(array($AIR_AUTO_FILE,$DATA_AIR_FILE2,$AIR_SCH_0,$AIR_SCH_1,$AIR_SCH_2,$AIR_SCH_3,$AIR_SCH_4,$AIR_SCH_5,$AIR_SCH_6,$AIR_GROUP_FILE))){
		air_log(basename(__FILE__),'Error: Cannot backup file to flash',LOG_ERR);
		exit;
	}

	closelog();
	
?>
