<?php
include_once('check_air_def.php');

$_LOGSEQ=0;

if (!function_exists('file_put_contents')) {
    function file_put_contents($filename, $data) {
        $f = @fopen($filename, 'w');
        if (!$f) {
            return false;
        } else {
            $bytes = fwrite($f, $data);
            fclose($f);
            return $bytes;
        }
    }
}

function load_air_data2($file){
	// nnnnnnnnnn
	// 1=AIR_ON, 2=AIR_OFF, 3=AIR_BYPASS, 4=AIR_FAN_ONLY
	$ret=array();
	$buf=file_get_contents($file);
	$air_id=1;
	for($i=0;$i<MAX_AIR;$i++){
		$d=substr($buf,$i,1);
		if(strlen($d)==1 && ($d==AIR_ON || $d==AIR_OFF || $d==AIR_BYPASS || $d==AIR_FAN_ONLY)){
			$ret[$air_id]=$d;
		}else{
			$ret[$air_id]=AIR_NOT_CHANGE;
		}
		$air_id++;
	}
	return($ret);
}

function air_state_txt($i){
	switch($i){
		case AIR_NOT_CHANGE: return 'AIR_NOT_CHANGE';
		case AIR_ON: return 'AIR_ON';
		case AIR_OFF: return 'AIR_OFF';
		case AIR_BYPASS: return 'AIR_BYPASS';
		case AIR_FAN_ONLY: return 'AIR_FAN_ONLY';
		default: return 'UNKNOWN';
	}
}

function get_average_temp($sensors)
{
    $sensorsA = get_temp($sensors);
    //echo "# sensor data: "; print_r($sensorsA);
    $count    = 0;
    $sum      = 0;
    foreach ($sensorsA as $sensor_name => $sensor_data) {
        if (!is_numeric($sensor_data))
            return false;
        air_log(__FUNCTION__,"sensor data: $sensor_name $sensor_data",LOG_DEBUG);
        $count++;
        $sum = $sum + $sensor_data;
    }
    return (round($sum / $count, 4));
}

function get_temp($sensors)
{
    // sensors: list of sensor id
    global $DATA_FILE;
    $ret = array();
    
    // init retrun array
    $sensorsA = explode(',', $sensors);
    foreach ($sensorsA as $sensor_name) {
        $ret[$sensor_name] = 'x';
    }
    
    $data = file_get_contents($DATA_FILE);
    foreach (explode("\n", $data) as $line) {
        $tmp = explode(" ", $line);
        if (count($tmp) < 2)
            continue;
        $sensor_name = $tmp[0];
        $sensor_data = $tmp[1];
        if (isset($ret[$sensor_name])) {
            air_log(__FUNCTION__,"# got $sensor_name: $line",LOG_DEBUG);
            $ret[$sensor_name] = $sensor_data;
        }
    }
    
    return $ret;
}

function save_air_state($air_state){
 global $TMPDIR;
 file_put_contents("$TMPDIR/air.save",serialize($air_state));
}

function load_air_state(){
 global $TMPDIR;
 $tmp=file_get_contents("$TMPDIR/air.save");
 if($tmp===false) return false;
 $tmp=unserialize($tmp);
 air_set_delay($tmp);
 return $tmp;
}

function is_air_on($AIR,$id){
	return $AIR[$id]['state']==AIR_ON;
}
function is_air_off($AIR,$id){
	return $AIR[$id]['state']==AIR_OFF;
}
function is_air_bypass($AIR,$id){
	return $AIR[$id]['state']==AIR_BYPASS;
}
function set_air(&$AIR,$id,$state){
	if(!is_numeric($id)) return;
	$AIR[$id]['target_state']=$state;
}
function set_air_type(&$AIR,$id,$t){
	if(!is_numeric($id)) return;
	$AIR[$id]['type']=$t;
}
function get_air_counter($AIR,$id){
	return @$AIR[$id]['count'];
}
function set_air_counter(&$AIR,$id,$count){
	if(!is_numeric($id)) return;
	$AIR[$id]['count']=intval($count);
}
function get_air_type($AIR,$id){
	return @$AIR[$id]['type'];
}

function write_cmd_file($AIR,$AIR_CMD_MAP){
	global $DATA_AIR_TO_BOARD;
	$cmds="";
	for($i=1;$i<=MAX_AIR;$i++){
		$state=$AIR[$i]['state'];
		if(!isset($AIR_CMD_MAP[$state])) return false;
		$cmds.=$AIR_CMD_MAP[$state];
	}
	air_log(__FUNCTION__,"cmd: $cmds",LOG_DEBUG);
	$ret=file_put_contents($DATA_AIR_TO_BOARD,$cmds);
	if($ret===false) return false;
	return $cmds;
}

function load_cmd_file(){
	$ret=array();
	global $DATA_AIR_TO_BOARD;
	$buf=file_get_contents($DATA_AIR_TO_BOARD);
	if($buf===false) return false;
	if(strlen($buf)!=24) return false;
	for($i=0;$i<MAX_AIR;$i++){
		$cmd=substr($buf,$i*3,3);
		switch($cmd){
			case "011": $ret[$i+1]=AIR_ON; break;
			case "110": $ret[$i+1]=AIR_OFF; break;
			case "100": $ret[$i+1]=AIR_OFF; break;
			case "000": $ret[$i+1]=AIR_BYPASS; break;
			case "010": $ret[$i+1]=AIR_FAN_ONLY; break;
			default: return false;
		}
	}
	return $ret;
}

function air_init(){
	global $AIR_CMD_MAP;
	$AIR=array();
	# load data from last command file
	$cmd=load_cmd_file();
	for($i=1;$i<=MAX_AIR;$i++){
		$AIR[$i]=array('state'=>AIR_BYPASS,'target_state'=>AIR_NOT_CHANGE,'count'=>0);
		if($cmd!==false){
			if(isset($AIR_CMD_MAP[$cmd[$i]])) $AIR[$i]['state']=$cmd[$i];
		}
		$AIR[$i]['dom']=AIR_DoM;
		$AIR[$i]['dob']=AIR_DoB;
	}
	return $AIR;
}
function air_set_delay(&$AIR){
	for($i=1;$i<=MAX_AIR;$i++){
		if(!isset($AIR[$i]['dom']))
			$AIR[$i]['dom']=AIR_DoM;
		if(!isset($AIR[$i]['dob']))
			$AIR[$i]['dob']=AIR_DoB;
		if($AIR[$i]['state']==AIR_ON || $AIR[$i]['state']==AIR_BYPASS){
			$AIR[$i]['dom']=AIR_DoM;
		}else{
			if($AIR[$i]['dom']>0) $AIR[$i]['dom']-=LOOP_TIME;
			if($AIR[$i]['dom']<0) $AIR[$i]['dom']=0;
		}
		if($AIR[$i]['state']==AIR_OFF || $AIR[$i]['state']==AIR_FAN_ONLY){
			$AIR[$i]['dob']=AIR_DoB;
		}else{
			if($AIR[$i]['dob']>0) $AIR[$i]['dob']-=LOOP_TIME;
			if($AIR[$i]['dob']<0) $AIR[$i]['dob']=0;
		}
	}
}

function air_log($tag,$msg,$priority=LOG_INFO){
	global $log_prio,$_LOGSEQ,$OS;
	$tag=basename($tag);
	#echo "# $tag: $msg\n";
	$p=LOG_DEBUG;
	if(isset($log_prio)) $p=$log_prio;
	if($priority<=$p){
		if($OS!='WIN'){
			syslog($priority, "# $_LOGSEQ $tag: $msg");
		}else{
			echo("# $_LOGSEQ $tag: $msg\n");
		}
		$_LOGSEQ=intval($_LOGSEQ)+1;
	}
	
}

function air_state($AIR,$id){
	return $AIR[$id]['state'];
}

function print_air($AIR,$id){
	echo "air $id: state=".air_state_txt($AIR[$id]['state'])." count=".$AIR[$id]['count']." target=".air_state_txt($AIR[$id]['target_state'])."\n";
}

function calc_air_generic($AIR,$id,$a_temp,$c_temp,$min_on,$min_off){
	if(!isset($AIR[1])||!isset($AIR[$id]['state'])||!isset($AIR[$id]['count'])||!isset($AIR[$id]['target_state'])) {
		air_log(__FUNCTION__, "Error: cannot get air$id state.",LOG_WARNING);
		return AIR_NOT_CHANGE;
	}
	if($a_temp === false) {
		air_log(__FUNCTION__, "Error: get air$id averate temp data error.",LOG_WARNING);
		return AIR_NOT_CHANGE;
	}
	air_log(__FUNCTION__, "air$id is ".air_state_txt(air_state($AIR,$id))." for ".((get_air_counter($AIR,$id)+1)*LOOP_TIME)." min");
	if(is_air_bypass($AIR,$id)){
		if((get_air_counter($AIR,$id)+1)*LOOP_TIME>=2){
			air_log(__FUNCTION__, "air is bypass at least 2min",LOG_DEBUG);
			if($a_temp <= $c_temp){
				air_log(__FUNCTION__, "air$id average temp $a_temp <= $c_temp, set AIR_OFF");
				return AIR_OFF;
			}else{
				air_log(__FUNCTION__, "air$id average temp $a_temp > $c_temp, set AIR_ON");
				return AIR_ON;
			}
		}
	}elseif(is_air_on($AIR,$id)){
		if((get_air_counter($AIR,$id)+1)*LOOP_TIME>=$min_on){ // check temp, if < AIR2_TEMP => turn off
			air_log(__FUNCTION__, "air$id is on at least ${min_on}min",LOG_DEBUG);
			if($a_temp < $c_temp ){
				air_log(__FUNCTION__, "air$id average temp $a_temp < $c_temp, set AIR_OFF");
				return AIR_OFF;
			}
		}
	}elseif(is_air_off($AIR,$id)){
		if((get_air_counter($AIR,$id)+1)*LOOP_TIME>=$min_off){
			air_log(__FUNCTION__, "air$id is off at least ${min_off}min",LOG_DEBUG);
			if($a_temp > $c_temp){
				air_log(__FUNCTION__, "air$id average temp $a_temp > $c_temp, set AIR_ON");
				return AIR_ON;
			}
		}
	}else{
		air_log(__FUNCTION__," air$id state ".$AIR[$id]['state']." ".air_state_txt(air_state($AIR,$id))." ignore");
	}
	return AIR_NOT_CHANGE;
}

function list_get_next($id,$list){
	$c=count($list);
	while($i=array_shift($list)){
		$list[]=$i;
		if($i==$id) break;
		$c--;
		if($c<0) break;
	}
	$new_id=array_shift($list);
	return $new_id;
}

function lpf($v,$name='default',$f=0.2){
	global $TMPDIR;
	$ret_var=$v;
	$tmp=@file_get_contents("$TMPDIR/lpf.save");
	if($tmp===false) $lpf_var=array();
	$lpf_var=@unserialize($tmp);
	if($lpf_var===false) $lpf_var=array();

	if(isset($lpf_var[$name])){
		$a=$lpf_var[$name];
        	air_log(__FUNCTION__,"old lpf: $name=$a",LOG_DEBUG);
		$diff=$v-$a;
		$a=$a+($diff*$f);
        	air_log(__FUNCTION__,"new lpf: $name=$a",LOG_DEBUG);
		$lpf_var[$name]=$a;
		$ret_var=$a;
	}else{
        	air_log(__FUNCTION__,"New low pass filter add: $name=$v");
		$lpf_var[$name]=$v;
		$ret_var=$v;
	}
	file_put_contents("$TMPDIR/lpf.save",serialize($lpf_var));
	return $ret_var;
}
function get_lpf($name){
	global $TMPDIR;
	$tmp=file_get_contents("$TMPDIR/lpf.save");
	if($tmp===false) return false;
	$lpf_var=unserialize($tmp);
	if($lpf_var===false) return false;
	if(!isset($lpf_var[$name])) return false;
	return $lpf_var[$name];
}
function get_air_state_from_board($board_file){
	$AIR=array();
	$f=fopen($board_file,'r');
	$AIRBIT='';
	while($line=trim(fgets($f))){
		if($line=="") break;
		if(feof($f)) break;
		$lineA=explode(' ',$line);
		if($lineA[0]=='Air_Bit'){
			$AIRBIT=$lineA[1];
		}
	}
	fclose($f);
	if(strlen($AIRBIT)==(MAX_AIR*3) && preg_match('/^[0-1]+$/',$AIRBIT)){
		air_log(__FUNCTION__,"got data: $AIRBIT",LOG_INFO);
		for($i=1;$i<=MAX_AIR;$i++){
			$AIR[$i]['count']=0;
			$AIR[$i]['target_state']=AIR_NOT_CHANGE;
			$state=substr($AIRBIT,($i-1)*3,3);
			switch($state){
				case "011":
					$AIR[$i]['state']=AIR_ON;
					set_air_type($AIR,$i,'main');
					air_log(__FUNCTION__,"set air $i main",LOG_INFO);
					break;
				case "110": $AIR[$i]['state']=AIR_OFF; break;
				case "100": $AIR[$i]['state']=AIR_OFF; break;
				case "000": $AIR[$i]['state']=AIR_BYPASS; break;
				case "010": $AIR[$i]['state']=AIR_FAN_ONLY; break;
			}
		}
		return $AIR;
	}else{
		return false;
	}
}

function backup_from_tmp_to_flash($files){
	global $TMPDIR, $CONFDIR;
	$ret=true;
	if(!is_array($files)) return false;
	foreach($files as $f){
		$fname=basename($f);
		$dst_file="$CONFDIR/backup/$fname";
		$src_file="$TMPDIR/$fname";
		if(!is_readable($src_file)){
			air_log(__FUNCTION__, "Cannot read $src_file",LOG_ERR);
			$ret=false;
			continue;
		}
		if(filesize($src_file)==0){
			air_log(__FUNCTION__, "$src_file is zero size",LOG_ERR);
			$ret=false;
			continue;
		}
		if(file_exists($dst_file)){
			if(!is_readable($dst_file) || !is_writable($dst_file)){
				air_log(__FUNCTION__, "cannot access $dst_file",LOG_ERR);
				$ret=false;
				continue;
			}
			$d_s=file_get_contents($src_file);
			$d_d=file_get_contents($dst_file);
			if($d_s===false || $d_d===false){
				air_log(__FUNCTION__, "cannot read $src_file or $dst_file",LOG_ERR);
				$ret=false;
				continue;
			}
			if(strcmp($d_s,$d_d)!==0){
				if(copy($src_file,$dst_file)){
					air_log(__FUNCTION__, "backup $src_file to $dst_file",LOG_INFO);
				}else{
					air_log(__FUNCTION__, "Cannot copy file to $dst_file",LOG_ERR);
					$ret=false;
					continue;
				}
			}
		}else{
			if(copy($src_file,$dst_file)){
				air_log(__FUNCTION__, "backup $src_file to $dst_file",LOG_INFO);
			}else{
				air_log(__FUNCTION__, "Cannot copy file to $dst_file",LOG_ERR);
				$ret=false;
				continue;
			}
		}
	}
	return($ret);
}

function restore_from_flash_to_tmp($files){
	global $TMPDIR, $CONFDIR;
	$ret=true;
	if(!is_array($files)) return false;
	foreach($files as $f){
		$fname=basename($f);
		$dst_file="$TMPDIR/$fname";
		$src_file="$CONFDIR/backup/$fname";
		if(file_exists($dst_file) && filesize($dst_file)>0 ) continue;
		if(!file_exists($src_file)){
			air_log(__FUNCTION__, "File $src_file not found",LOG_ERR);
			$ret=false;
			continue;
		}
		if(!is_readable($src_file)){
			air_log(__FUNCTION__, "Cannot read $src_file",LOG_ERR);
			$ret=false;
			continue;
		}
		if(copy($src_file,$dst_file)){
			air_log(__FUNCTION__, "Restore $dst_file from $src_file",LOG_INFO);
		}else{
			air_log(__FUNCTION__, "Cannot copy file to $dst_file",LOG_ERR);
			$ret=false;
			continue;
		}
	}
	return($ret);
}

function get_air_auto($file){
	$buf=file_get_contents($file);
	if($buf===false) return(-1);
	return(intval($buf));
}

function get_air_group($f){
	// TODO: read from air_group.txt
	$air_group=array();
	$buff = file_get_contents($f);
	if($buff === false){
		air_log(__FUNCTION__,'Error: cannot load air group file.',LOG_ERR);
		return $ret;
	}
	$g_id=1;
	foreach(explode("\n",$buff) as $line){
		$ret=array();
		$line=trim($line);
		if($line=="") continue;
		if(substr($line,0,1)=='#') continue;
		foreach(explode(";",$line) as $item){
			$item=trim($item);
			$kv=explode("=",$item);
			$k=trim($kv[0]); $v=trim($kv[1]);
			switch($k){
			case "air_list":
				$tmp=array();
				foreach(explode(",",$v) as $a){
					if(is_numeric($a) && $a>0 && $a<=MAX_AIR){
						$tmp[]=intval($a);
					}else{
						air_log(__FUNCTION__,'air_list error: "'.$a.'"',LOG_WARNING);
					}
				}
				$ret['air_list']=$tmp;
				break;
			case "num_main":
				if(is_numeric($v) && $v>=0 && $v<=MAX_AIR)
					$ret['num_main']=intval($v);
				else
					$ret['num_main']=0;
				break;
			case "switch_main_h":
				if(is_numeric($v) && $v>0)
					$ret['switch_main_h']=$v;
				else
					$ret['switch_main_h']=24;
				break;
			case "min_backup_time_m":
				if(is_numeric($v) && $v>0)
					$ret['min_backup_time_m']=$v;
				break;
			case "temp_cond1":
				if(is_numeric($v) && $v>0)
					$ret['temp_cond1']=$v;
				else
					$ret['temp_cond1']=27;
				break;
			case "temp_cond2":
				if(is_numeric($v) && $v>0)
					$ret['temp_cond2']=$v;
				else
					$ret['temp_cond2']=30;
				break;
			case "temp_sensors":
				$ret['temp_sensors']=$v;
				break;
			case "wait_all_main_on_state":
        $ret['wait_all_main_on_state']=$v;
        break;
			}
		}
		$air_group[$g_id]=$ret;
		$g_id++;
	}
	return $air_group;
}

?>
