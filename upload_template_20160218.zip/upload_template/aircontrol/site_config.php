<?php
$NUM_AIR=2;	# Total number of air
#$AIR_WEIGHT[2]=2;
#$AIR_WEIGHT[3]=2;

$default_a_temp=25;
$MIN_BACKUP_ON_TIME=15;

?>
