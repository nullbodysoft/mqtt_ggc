<?php

	define('MAX_AIR',10);
	
	define('AIR_NOT_CHANGE',0);
	define('AIR_ON',1);
	define('AIR_OFF',2);
	define('AIR_BYPASS',3);
	define('AIR_FAN_ONLY',4);

	define('LOOP_TIME',1);

	define('AIR2_TEMP',23);

	$AIR_CMD_MAP=array(AIR_ON=>'011',AIR_OFF=>'110',AIR_BYPASS=>'000',AIR_FAN_ONLY=>'010');
	//$AIR_CMD_MAP=array(AIR_ON=>'011',AIR_OFF=>'100',AIR_BYPASS=>'000',AIR_FAN_ONLY=>'010');

	$OS = strtoupper(substr(PHP_OS,0,3));
	if( $OS == 'WIN' ){
		$TMPDIR = "d:/tmp";
		$CONFDIR = ".";
	}else{
		$TMPDIR    = "/tmp";
		$CONFDIR   = "/root/aircontrol";
		
	}
	if(is_dir('/cofs/tmp') && is_dir('/cofs/etc/snmp')){
        	$TMPDIR    = "/cofs/tmp";
        	$CONFDIR   = "/cofs/etc/snmp";
	}

	$INIT_FILE = "$TMPDIR/serial.run";
	$DATA_FILE = "$TMPDIR/temp_data.txt"; # temperature file
	$AIR_BIT_FILE = "$TMPDIR/air_data.txt";
	//$DATA_AIR_FILE = "$TMPDIR/data_air.txt";
	//$SENSOR_ID_FILE = "$CONFDIR/data_condition.txt"; # not use
	//$SENSOR_VALUE_COND = "$CONFDIR/value_condition.txt"; # not use
	$DATA_AIR_TO_BOARD = "$TMPDIR/data_air_to_board.txt"; # cmd to controler
	
	$AIR_AUTO_FILE = "$TMPDIR/auto_from_server.txt";
	$DATA_AIR_FILE2 = "$TMPDIR/data_from_server.txt";
	$AIR_SCH_0 = "$TMPDIR/air_schedule_0.txt";
	$AIR_SCH_1 = "$TMPDIR/air_schedule_1.txt";
	$AIR_SCH_2 = "$TMPDIR/air_schedule_2.txt";
	$AIR_SCH_3 = "$TMPDIR/air_schedule_3.txt";
	$AIR_SCH_4 = "$TMPDIR/air_schedule_4.txt";
	$AIR_SCH_5 = "$TMPDIR/air_schedule_5.txt";
	$AIR_SCH_6 = "$TMPDIR/air_schedule_6.txt";

	$AIR_GROUP_FILE = "$TMPDIR/air_group.txt";

	define('AIR_DoM',3); // delay on make
	define('AIR_DoB',3); // delay on break
	
	$AIR_WEIGHT=array();
	for($i=1 ; $i<=MAX_AIR; $i++) $AIR_WEIGHT[$i]=1;
?>
